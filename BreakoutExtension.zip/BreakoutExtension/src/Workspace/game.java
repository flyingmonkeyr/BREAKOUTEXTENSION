package Workspace;

import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

public class game extends Graphics {

    //class variables
    /** Width and height of application window in pixels */
    public static final int APPLICATION_WIDTH = 800;
    public static final int APPLICATION_HEIGHT = 600;

    /** Dimensions of game board (usually the same) */
    private static final int WIDTH = APPLICATION_WIDTH;
    private static final int HEIGHT = APPLICATION_HEIGHT;

    /** Dimensions of the paddle */
    private static final int PADDLE_WIDTH = 60;
    private static final int PADDLE_HEIGHT = 90;

    /** Offset of the paddle up from the bottom */
    private static final int PADDLE_X_OFFSET = 30;

    /** Number of bricks per column */
    private static final int NBRICKS_PER_COLUMN = 10;

    /** Number of columns of bricks */
    private static final int NBRICK_COLUMNS = 10;

    /** Separation between bricks */
    private static final int BRICK_SEP = 4;

    /** Height of a brick */
    private static final int BRICK_HEIGHT = (HEIGHT - (NBRICKS_PER_COLUMN - 1) * BRICK_SEP) / NBRICKS_PER_COLUMN;

    /** Width of a brick */
    private static final int BRICK_WIDTH = 8;

    /** Radius of the cube in pixels */
    private static final int cube_RADIUS = 10;

    /** Offset of the top brick row from the top */
    private static final int BRICK_Y_OFFSET = 70;

    /** Number of turns */
    private static final int NTURNS = 3;

    /** Speed in the X */
    private static final int XSPEED = 3;


    //runs when object is created
    public game(){
        setUpBricks();
        
    }

    @Override
    public Graphics create() {
        return null;
    }

    @Override
    public void translate(int x, int y) {

    }

    @Override
    public Color getColor() {
        return null;
    }

    @Override
    public void setColor(Color c) {

    }

    @Override
    public void setPaintMode() {

    }

    @Override
    public void setXORMode(Color c1) {

    }

    @Override
    public Font getFont() {
        return null;
    }

    @Override
    public void setFont(Font font) {

    }

    @Override
    public FontMetrics getFontMetrics(Font f) {
        return null;
    }

    @Override
    public Rectangle getClipBounds() {
        return null;
    }

    @Override
    public void clipRect(int x, int y, int width, int height) {

    }

    @Override
    public void setClip(int x, int y, int width, int height) {

    }

    @Override
    public Shape getClip() {
        return null;
    }

    @Override
    public void setClip(Shape clip) {

    }

    @Override
    public void copyArea(int x, int y, int width, int height, int dx, int dy) {

    }

    @Override
    public void drawLine(int x1, int y1, int x2, int y2) {

    }

    @Override
    public void fillRect(int x, int y, int width, int height) {

    }

    @Override
    public void clearRect(int x, int y, int width, int height) {

    }

    @Override
    public void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {

    }

    @Override
    public void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {

    }

    @Override
    public void drawOval(int x, int y, int width, int height) {

    }

    @Override
    public void fillOval(int x, int y, int width, int height) {

    }

    @Override
    public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle) {

    }

    @Override
    public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle) {

    }

    @Override
    public void drawPolyline(int[] xPoints, int[] yPoints, int nPoints) {

    }

    @Override
    public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints) {

    }

    @Override
    public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints) {

    }

    @Override
    public void drawString(String str, int x, int y) {

    }

    @Override
    public void drawString(AttributedCharacterIterator iterator, int x, int y) {

    }

    @Override
    public boolean drawImage(Image img, int x, int y, ImageObserver observer) {
        return false;
    }

    @Override
    public boolean drawImage(Image img, int x, int y, int width, int height, ImageObserver observer) {
        return false;
    }

    @Override
    public boolean drawImage(Image img, int x, int y, Color bgcolor, ImageObserver observer) {
        return false;
    }

    @Override
    public boolean drawImage(Image img, int x, int y, int width, int height, Color bgcolor, ImageObserver observer) {
        return false;
    }

    @Override
    public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, ImageObserver observer) {
        return false;
    }

    @Override
    public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, Color bgcolor, ImageObserver observer) {
        return false;
    }

    @Override
    public void dispose() {

    }

    private void setUpBricks() {
        // make a column of bricks for each of 10 iterative steps
        for (int column = 1; column <= NBRICK_COLUMNS; column++) {




            // starting x coordinate: current column and involved constants
            /*
            int screenCenter = BreakoutExtensionGame.BreakoutExtensionFrame.getWidth() / 2;
            int startingOffsetFromCenter = (NBRICK_COLUMNS * (BRICK_SEP + BRICK_WIDTH)) / 2;
            int offsetFromDimension = BRICK_SEP / 2;
            int stepOffset = (column - 1) * (BRICK_SEP + BRICK_WIDTH);

            int x = ((screenCenter - startingOffsetFromCenter) + offsetFromDimension)
                    + stepOffset;

            //error print
            System.out.println(x);

            //make the column
            makeBrickColumn(x);

             */
        }
    }

    private void makeBrickColumn(int x) {
        // add the bricks in the column through a loop involving the brick number
        for (int brick_num = 1; brick_num <= NBRICKS_PER_COLUMN; brick_num++) {



            // brick y coordinates: set constants and the brick_num
            int yStep = ((BRICK_HEIGHT + BRICK_SEP) * (brick_num - 1));
            int yDefaultOffset = BRICK_SEP / 2;
            int y = yDefaultOffset + yStep;

            // make a brick of the set dimensions
            System.out.println("making brick");
            this.setColor(Color.RED);
            this.fillRect(x, y, BRICK_WIDTH, BRICK_HEIGHT);

        }
    }

    public void paintComponent(Graphics g){

       // super.paintComponent(this);

        g.setColor(Color.RED);
        g.fillRect(brickX, brickY, brickWidth, brickHeight);
    }

    //instance variables
    int brickWidth;
    int brickHeight;
    int brickX;
    int brickY;

}
