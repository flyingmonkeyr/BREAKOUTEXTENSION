package Workspace;

import org.w3c.dom.css.Rect;

import java.awt.*;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;
import javax.swing.JFrame;
import javax.swing.JPanel;

/*
This is a game which is an extension on Breakout. Columns of bricks will be set up in the center of the screen to be hit by an object that flies around the screen based on collision physics.
When a brick is hit by the object, it gets destroyed and disappears. An animated break can be added later but isn't required.
Two paddles, one on each side of the screen, also governing the motion of the object, are controlled by two players with keys to bounce the ball back and forth.
When a ball passes a paddle to the "backboard" of the screen (left and right sides), the respective player will lose a life, and the ball will return to one of two constant locations.
If one player is out of lives, the other wins the game.

To build the column of bricks, for loops are used to cycle through columns and paint the array of bricks onto the screen
Each brick needs indexes in two arrays, one keeping track of its location, and one keeping track of the brick's status as solid, broken, or in the process of breaking (if the animation is added)

The object bounces off everything with normal collision physics. However, when hit by one of the players, it will switch to the state of the player
(for example, if hitting one side, it will turn into an orange cube. Hitting the other one will turn it into a purple cube.)
When it hits either the left or right wall, the round will reset and the ball will return to one of two constant locations with a random angular velocity toward the respective location.
50/50 chance for each of the two constant locations.

The two paddles are governed by keyListeners on W/S and UpArrow/DownArrow.
They reset to default locations at the beginning of each new round.

During the end of each round, before a new one starts, a life is subtracted from the respective character. If one player runs out of lives, the screen is cleared.
The screen will then display the winning player.
 */

public class BreakoutExtensionGame extends JFrame {

    //class constants
    /** Width and height of application window in pixels */
    public static final int APPLICATION_WIDTH = 800;
    public static final int APPLICATION_HEIGHT = 600;


    public BreakoutExtensionGame() {

        //setting up the graphics window for the game
        super.setTitle("Breakout!(Extension)");
        super.setSize(APPLICATION_WIDTH,APPLICATION_HEIGHT);
        super.setResizable(false);
        super.add(new gamePanel());
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setVisible(true);

    }

    public static void main(String[] args) {
        new BreakoutExtensionGame();
    }

}
