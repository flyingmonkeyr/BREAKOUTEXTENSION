package Workspace;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;
import javax.swing.*;
import acm.util.RandomGenerator;
import java.io.*;



public class gamePanel extends JPanel implements ActionListener, KeyListener{

    //class variables and constants
    //Each brick needs indexes in two arrays, one keeping track of its location, and one keeping track of the brick's status as solid (1), broken (2),
    //or in the process of breaking (3) (if the animation is added)
    int totalBricks = NBRICKS_PER_COLUMN*NBRICK_COLUMNS;
    brickFrame[] brickArray = new brickFrame[totalBricks + 1];
    int[] brickStatusArray = new int[totalBricks + 1];

     /**
     * Width and height of application window in pixels
     */
    public static final int APPLICATION_WIDTH = 800;
    public static final int APPLICATION_HEIGHT = 600;

    /**
     * Dimensions of game board (usually the same)
     */
    private static final int WIDTH = APPLICATION_WIDTH;
    private static final int HEIGHT = APPLICATION_HEIGHT;

    /**
     * Dimensions of the paddle
     */
    private static final int PADDLE_WIDTH = 60;
    private static final int PADDLE_HEIGHT = 90;

    /**
     * Offset of the paddles from the sides
     */
    private static final int PADDLE_X_OFFSET = 30;

    /**
     * Number of bricks per column
     */
    private static final int NBRICKS_PER_COLUMN = 10;

    /**
     * Number of columns of bricks
     */
    private static final int NBRICK_COLUMNS = 10;

    /**
     * Separation between bricks
     */
    private static final int BRICK_SEP = 4;

    /**
     * Height of a brick
     */
    private static final int BRICK_HEIGHT = (APPLICATION_HEIGHT - ((NBRICKS_PER_COLUMN - 1) * BRICK_SEP)) / NBRICKS_PER_COLUMN - 3;

    /**
     * Width of a brick
     */
    private static final int BRICK_WIDTH = 8;

    /**
     * Radius of the cube in pixels
     */
    private static final int cube_RADIUS = 10;

    /**
     * Offset of the top brick row from the top
     */
    private static final int BRICK_Y_OFFSET = 70;

    /**
     * Number of turns
     */
    private static final int NTURNS = 3;

    /**
     * Speed in the X
     */
    private static final int XSPEED = 3;




    //more declarations
    private Image A;
    private Image B;
    private int x = 100, y = 100;
    private Timer timer;


    public gamePanel() {

        //set it to double buffered to make graphics smoother
        super.setDoubleBuffered(true);

        System.out.println("initializing game");
        initializeGame();

        //start the timer which will rerun the program through action listener
        timer = new Timer(20, this);
        timer.start();

        /*
        Container c = super.getContentPane();
        c.add(new JFrame());
        */
    }

    private void initializeGame() {
        initArrays();
        initPaddles();
        initBall();

        //initialize key listener
        System.out.println(this.isFocusable());
        this.setFocusable(true);
        addKeyListener(this);
    }

    private void initBall() {

        newRound = true;
        //will be called during each reset to set the state of the ball
        if (rgen.nextInt(1,2) == 1){
            System.out.println("starting ball on left");
            onLeft = true;
            initBallOnLeft();
        }
        else{
            System.out.println("starting ball on right");
            onLeft = false;
            initBallOnRight();
        }
    }

    private void initBallOnRight() {

        iiball = new ImageIcon(this.getClass().getResource("tiny purple cube.PNG"));
        ballStartingX = 3*(APPLICATION_WIDTH/4) - (iiball.getIconWidth()/2);
        ballStartingY = (APPLICATION_HEIGHT/2) - (iiball.getIconHeight()/2);
        //set the width and height for future use
        ballWidth = iiball.getIconWidth();
        ballHeight = iiball.getIconHeight();

        //set the ball image
        ball = iiball.getImage();

    }

    private void initBallOnLeft() {

        iiball = new ImageIcon(this.getClass().getResource("tiny orange cube.PNG"));
        ballStartingX = (APPLICATION_WIDTH/4) - (iiball.getIconWidth()/2);
        ballStartingY = (APPLICATION_HEIGHT/2) - (iiball.getIconHeight()/2);
        //set the width and height for future use
        ballWidth = iiball.getIconWidth();
        ballHeight = iiball.getIconHeight();

        //set the ball image
        ball = iiball.getImage();

    }

    private void initPaddles() {
        //initialize everything non-graphics
        int middleY = APPLICATION_HEIGHT/2;

        //apparently needs to be instantiated again
        ii = new ImageIcon(this.getClass().getResource("small 1898A.PNG"));
        ii2 = new ImageIcon(this.getClass().getResource("small 1898R.PNG"));

        //initialize the width and height of the paddles
        paddleAWidth = ii.getIconWidth();
        paddleAHeight = ii.getIconHeight();
        paddleBWidth = ii2.getIconWidth();
        paddleBHeight = ii2.getIconHeight();

        //initialize starting locations for paddles
        paddleAStartingY = middleY - ii.getIconHeight()/2;
        paddleBStartingY = middleY - ii2.getIconHeight()/2;

        //start the new round
        startingRound = true;
    }

    private void initArrays() {
        for (column = 1; column <= NBRICK_COLUMNS; column++) {

            // starting x coordinate: current column and involved constants
            int screenCenter = APPLICATION_WIDTH / 2;
            int startingOffsetFromCenter = (NBRICK_COLUMNS * (BRICK_SEP + BRICK_WIDTH)) / 2;
            int offsetFromDimension = BRICK_SEP / 2;
            int stepOffset = (column - 1) * (BRICK_SEP + BRICK_WIDTH);

            int x = ((screenCenter - startingOffsetFromCenter) + offsetFromDimension)
                    + stepOffset;

            for (int brick_num = 1; brick_num <= NBRICKS_PER_COLUMN; brick_num++) {

                // brick y coordinates: set constants and the brick_num
                int yStep = ((BRICK_HEIGHT + BRICK_SEP) * (brick_num - 1));
                int yDefaultOffset = BRICK_SEP / 2;
                int y = yDefaultOffset + yStep;

                //fill out a brickFrame, index (for brick number, and for brick state)
                int bricksFromPastColumns = (column - 1) * NBRICKS_PER_COLUMN;
                System.out.println("bricksFromPastColumns: " + bricksFromPastColumns);
                brickArray[bricksFromPastColumns + brick_num - 1] = new brickFrame(x, y, BRICK_WIDTH, BRICK_HEIGHT);

                //set up the status of the brick from undefined to present (animation here later)
                brickStatusArray[bricksFromPastColumns + brick_num - 1] = 1;

                System.out.println("bx: " + brickArray[bricksFromPastColumns + brick_num-1].bx + "  by: " + brickArray[bricksFromPastColumns + brick_num-1].by);
                System.out.println(brickStatusArray[bricksFromPastColumns + brick_num-1]);

            }
        }
    }

    public void paintComponent(Graphics g) {

        //clear the screen for repainting
        super.paintComponent(g);

//        System.out.println("painting");
        //set A equal to the image file for 189a8A
        setUpA();

        //cast g into a Graphics2D object for drawing graphics
        graphics = (Graphics2D) g;

        //drawing the graphics
//        System.out.println("new setup");
        paintBricks();
        drawPaddles();
        drawBall();

    }

    private void drawBall() {

        if (newRound == true){
            //random y velocity
            if (rgen.nextInt(1,2) == 1){
                vy = rgen.nextDouble(3.0, 10.0);
            }
            else{
                vy = rgen.nextDouble(-10.0, -3.0);
            }

            //which direction for the ball to move
            if (onLeft == true){
                vx = -5;
            }
            else{
                vx = 5;
            }

            //draw ball to screen
            graphics.drawImage(ball, ballStartingX, ballStartingY, this);

            ballLocX = ballStartingX;
            ballLocY = ballStartingY;

            newRound = false;
        }

        //update ball location
        ballLocX += vx;
        ballLocY += vy;

        //redraw the ball
        graphics.drawImage(ball, ballLocX, ballLocY, this);

        //check for collisions
        checkCollisions();
    }

    private void checkCollisions() {
        //check top/bottom wall collisions
        topBottomCollisions();

        //check left wall
        leftWallCollisions();

        //check right wall
        rightWallCollisions();

        //check bricks
        brickCollisions();

        //check paddles
        paddleCollisions();

    }

    private void paddleCollisions() {
        //check all 4 corners of the ball for paddles
        //top left corner: paddle a
        if (ballLocY >= paddleABounds.getY() && ballLocY <= paddleABounds.getY() + paddleABounds.getHeight() && ballLocX <= paddleABounds.getX() + paddleABounds.getWidth() && ballLocX >= paddleABounds.getX()){
            //only flip the direction if it's facing the wrong direction
            if (vx < 0){
                vx= -vx;
                initBallOnLeft();
            }
        }

        //bottom left corner: paddle a
        if (ballLocY + ballHeight >= paddleABounds.getY() && ballLocY + ballHeight <= paddleABounds.getY() + paddleABounds.getHeight() && ballLocX <= paddleABounds.getX() + paddleABounds.getWidth() && ballLocX >= paddleABounds.getX()){
            //only flip the direction if it's facing the wrong direction
            if (vx < 0){
                vx= -vx;
                initBallOnLeft();
            }
        }

        //top right corner: paddle a
        if (ballLocY >= paddleABounds.getY() && ballLocY <= paddleABounds.getY() + paddleABounds.getHeight() && ballLocX + ballWidth <= paddleABounds.getX() + paddleABounds.getWidth() && ballLocX + ballWidth >= paddleABounds.getX()){
            //only flip the direction if it's facing the wrong direction
            if (vx < 0){
                vx= -vx;
                initBallOnLeft();
            }
        }

        //bottoms right corner: paddle a
        if (ballLocY + ballHeight >= paddleABounds.getY() && ballLocY + ballHeight <= paddleABounds.getY() + paddleABounds.getHeight() && ballLocX + ballWidth <= paddleABounds.getX() + paddleABounds.getWidth() && ballLocX + ballWidth >= paddleABounds.getX()){
            //only flip the direction if it's facing the wrong direction
            if (vx < 0){
                vx= -vx;
                initBallOnLeft();
            }
        }


        //top left corner: paddle b
        if (ballLocY >= paddleBBounds.getY() && ballLocY <= paddleBBounds.getY() + paddleBBounds.getHeight() && ballLocX <= paddleBBounds.getX() + paddleBBounds.getWidth() && ballLocX >= paddleBBounds.getX()){
            //only flip the direction if it's facing the wrong direction
            if (vx > 0){
                vx= -vx;
                initBallOnRight();
            }
        }

        //bottom left corner: paddle b
        if (ballLocY + ballHeight >= paddleBBounds.getY() && ballLocY + ballHeight <= paddleBBounds.getY() + paddleBBounds.getHeight() && ballLocX <= paddleBBounds.getX() + paddleBBounds.getWidth() && ballLocX >= paddleBBounds.getX()){
            //only flip the direction if it's facing the wrong direction
            if (vx > 0){
                vx= -vx;
                initBallOnRight();
            }
        }

        //top right corner: paddle b
        if (ballLocY >= paddleBBounds.getY() && ballLocY <= paddleBBounds.getY() + paddleBBounds.getHeight() && ballLocX + ballWidth <= paddleBBounds.getX() + paddleBBounds.getWidth() && ballLocX + ballWidth >= paddleBBounds.getX()){
            //only flip the direction if it's facing the wrong direction
            if (vx > 0){
                vx= -vx;
                initBallOnRight();
            }
        }

        //bottoms right corner: paddle b
        if (ballLocY + ballHeight >= paddleBBounds.getY() && ballLocY + ballHeight <= paddleBBounds.getY() + paddleBBounds.getHeight() && ballLocX + ballWidth <= paddleBBounds.getX() + paddleBBounds.getWidth() && ballLocX + ballWidth >= paddleBBounds.getX()){
            //only flip the direction if it's facing the wrong direction
            if (vx > 0){
                vx= -vx;
                initBallOnRight();
            }
        }

    }


    private void brickCollisions() {
        //cycle through all brick locations
        for (int i = 0; i < NBRICKS_PER_COLUMN*NBRICK_COLUMNS; i++){
            //check all 4 corners of bounding box
            //top left of ball
            System.out.println(brickArray[i].bx);
            //top left
            if (ballLocX >= brickArray[i].bx && ballLocX <= brickArray[i].bx + BRICK_WIDTH && ballLocY >= brickArray[i].by && ballLocY <= brickArray[i].by + BRICK_HEIGHT && brickStatusArray[i] == 1){
                //error print
                System.out.println("Yes");

                //set to invisible
                brickStatusArray[i] = 2;
                //reverse vx and vy
                vx = -vx;
            }
            //bottom left
            if (ballLocX >= brickArray[i].bx && ballLocX <= brickArray[i].bx + BRICK_WIDTH && ballLocY + ballHeight >= brickArray[i].by && ballLocY + ballHeight <= brickArray[i].by + BRICK_HEIGHT && brickStatusArray[i] == 1){
                //error print
                System.out.println("Yes");

                //set to invisible
                brickStatusArray[i] = 2;
                //reverse vx and vy
                vx = -vx;
            }
            //top right
            if (ballLocX + ballWidth >= brickArray[i].bx && ballLocX  + ballWidth <= brickArray[i].bx + BRICK_WIDTH && ballLocY >= brickArray[i].by && ballLocY <= brickArray[i].by + BRICK_HEIGHT && brickStatusArray[i] == 1){
                //error print
                System.out.println("Yes");

                //set to invisible
                brickStatusArray[i] = 2;
                //reverse vx and vy
                vx = -vx;
            }

            //bottom right
            if (ballLocX + ballWidth >= brickArray[i].bx && ballLocX + ballWidth <= brickArray[i].bx + BRICK_WIDTH && ballLocY + ballHeight >= brickArray[i].by && ballLocY + ballHeight <= brickArray[i].by + BRICK_HEIGHT && brickStatusArray[i] == 1){
                //error print
                System.out.println("Yes");

                //set to invisible
                brickStatusArray[i] = 2;
                //reverse vx and vy
                vx = -vx;
            }
        }
    }

    private void rightWallCollisions() {
        if ((ballLocX + ballWidth) >= APPLICATION_WIDTH){
            //reverse vx, take away a life from the respective player and reset the ball
            vx = -vx;
            gameOver = true;
        }
    }

    private void leftWallCollisions() {
        if (ballLocX <= 0){
            //reverse vx, take away a life from the respective player and reset the ball
            vx = -vx;
            gameOver = true;
        }
    }

    private void topBottomCollisions() {
        if (ballLocY <= 0){
            vy = -vy;
        }
        else if ((ballLocY + 2*ballHeight) >= APPLICATION_HEIGHT){
            vy = -vy;
        }
    }


    private void drawPaddles() {

        if (newRound == true){
//            System.out.println(paddleAStartingY);
//            System.out.println(paddleBStartingY);
            graphics.drawImage(A, PADDLE_X_OFFSET, paddleAStartingY, this);
            graphics.drawImage(B, APPLICATION_WIDTH - (PADDLE_X_OFFSET + ii2.getIconWidth()), paddleBStartingY, this);

            //initialize bounding boxes
            paddleABounds = new Rectangle(PADDLE_X_OFFSET, paddleAStartingY, paddleAWidth, paddleAHeight);
            paddleBBounds = new Rectangle(APPLICATION_WIDTH - (PADDLE_X_OFFSET + ii2.getIconWidth()), paddleBStartingY, paddleBWidth, paddleBHeight);

            //initialize lastY variables
            paddleALastY = paddleAStartingY;
            paddleBLastY = paddleBStartingY;
        }

        //update location on screen
        graphics.drawImage(A, PADDLE_X_OFFSET, (int) paddleABounds.getY(), this);
        graphics.drawImage(B, APPLICATION_WIDTH - (PADDLE_X_OFFSET + ii2.getIconWidth()), (int) paddleBBounds.getY(), this);

    }

    /*
        To build the column of bricks, for loops are used to cycle through columns and paint the array of bricks onto the screen
        Each brick needs indexes in two arrays, one keeping track of its location, and one keeping track of the brick's status as solid, broken, or in the process of breaking (if the animation is added)
     */

    private void paintBricks() {

        // make a column of bricks for each of 10 iterative steps
        for (column = 1; column <= NBRICK_COLUMNS; column++) {

            // starting x coordinate: current column and involved constants
            int screenCenter = APPLICATION_WIDTH / 2;
            int startingOffsetFromCenter = (NBRICK_COLUMNS * (BRICK_SEP + BRICK_WIDTH)) / 2;
            int offsetFromDimension = BRICK_SEP / 2;
            int stepOffset = (column - 1) * (BRICK_SEP + BRICK_WIDTH);

            int x = ((screenCenter - startingOffsetFromCenter) + offsetFromDimension)
                    + stepOffset;

            //error print
//            System.out.println(x);

            //make the column
            makeBrickColumn(x);
        }
    }

    private void makeBrickColumn(int x) {

        // add the bricks in the column through a loop involving the brick number
        for (int brick_num = 1; brick_num <= NBRICKS_PER_COLUMN; brick_num++) {

            // brick y coordinates: set constants and the brick_num
            int yStep = ((BRICK_HEIGHT + BRICK_SEP) * (brick_num - 1));
            int yDefaultOffset = BRICK_SEP / 2;
            int y = yDefaultOffset + yStep;


            // make a brick of the set dimensions to display to the screen if it is visible
            //System.out.println("making brick");
            if (brickStatusArray[((column-1)*NBRICKS_PER_COLUMN) + brick_num-1] == 1){
                graphics.setColor(Color.RED);
                graphics.fillRect(x, y, BRICK_WIDTH, BRICK_HEIGHT);
            }

        }

    }

    private void setUpA() {

        //define the image of 1898A
        ii = new ImageIcon(this.getClass().getResource("small 1898A.PNG"));
        A = ii.getImage();
        //A2 = A.getScaledInstance(50, 50, Image.SCALE_DEFAULT);

        //define the image of 1898R
        ii2 = new ImageIcon(this.getClass().getResource("small 1898R.PNG"));
        B = ii2.getImage();
        //B2 = B.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
        //scale image down
        //A2 = A.getScaledInstance(50,50,Image.SCALE_SMOOTH);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //run the game normally, when gameover becomes true execute the gameOver method
        if (gameOver == false){
            repaint();
        }
    }

    private void gameOver() {
        //display a game over label to the screen
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    public void keyPressed(KeyEvent e) {

//        System.out.println("Key Pressed");

        //W
        if (e.getKeyChar() == 'w') {
            paddleALastY = paddleALastY - 30;
            paddleABounds.setLocation(PADDLE_X_OFFSET, paddleALastY);
        }
        //S
        else if (e.getKeyCode() == 83) {
            paddleALastY = paddleALastY + 30;
            paddleABounds.setLocation(PADDLE_X_OFFSET, paddleALastY);
        }
        //up arrow
        else if (e.getKeyCode() == 38) {
            paddleBLastY = paddleBLastY - 30;
            paddleBBounds.setLocation(APPLICATION_WIDTH - (PADDLE_X_OFFSET + ii2.getIconWidth()), paddleBLastY);
        }
        //down arrow
        else if (e.getKeyCode() == 40) {
            paddleBLastY = paddleBLastY + 30;
            paddleBBounds.setLocation(APPLICATION_WIDTH - (PADDLE_X_OFFSET + ii2.getIconWidth()), paddleBLastY);
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }


    //instance variables
    ImageIcon ii;
    ImageIcon ii2;
    ImageIcon iia;
    ImageIcon ii2a;
    Graphics2D graphics;
    Image A2;
    Image B2;
    int column = 1;

    int paddleAStartingY;
    int paddleBStartingY;

    int ballStartingX;
    int ballStartingY;

    boolean startingRound;

    ImageIcon iiball;
    Image ball;

    //new random generator and corresponding instance variable boolean
    private RandomGenerator rgen = RandomGenerator.getInstance();
    private boolean onLeft;

    private boolean newRound;

    private double vx = 10;
    private double vy;

    private int ballLocX;
    private int ballLocY;

    private int ballHeight;
    private int ballWidth;

    private int paddleAWidth;
    private int paddleAHeight;
    private Rectangle paddleABounds;

    private int paddleBWidth;
    private int paddleBHeight;
    private Rectangle paddleBBounds;

    private int paddleALastY;
    private int paddleBLastY;

    private boolean gameOver = false;
}
