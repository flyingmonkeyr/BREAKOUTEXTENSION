package Workspace;

//imports
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;
import javax.swing.*;

//this class forms rectangles around each brick displayed to the screen. This serves to track each brick's location on the screen as well as its state: present (1), broken (2), or breaking (3).
public class brickFrame extends Rectangle{

    //initializing class for the object
    public brickFrame(int x, int y, int width, int height){
        //set the variables for the brickFrame for public use
        bx = x;
        by = y;
        bwidth = width;
        bheight = height;

        //create the rectangle
        thisRect = new Rectangle(x, y, width, height);
    }

    //public toString methods
    public String stateToString(){
        if(state == 1){
            return "present";
        }
        else if(state == 2){
            return "broken";
        }
        else if(state == 3){
            return "breaking";
        }
        else{
            return null;
        }
    }

    public int getState(){
        return state;
    }

    public int state = 0;
    public Rectangle thisRect;
    public int bx;
    public int by;
    public int bwidth;
    public int bheight;

}
