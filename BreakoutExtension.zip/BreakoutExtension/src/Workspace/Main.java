package Workspace;

//imports
import java.awt.Canvas;
import java.awt.Graphics;
import javax.swing.JFrame;

public class Main {

    public static void main(String[] args) {
	// write your code here
        BreakoutExtensionGame gamePlay = new BreakoutExtensionGame();
    }




}
